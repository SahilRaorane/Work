package main.scala.assignment_01

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._

object assignment_01 {
  def main(args: Array[String]): Unit = {
    // Initialize SparkSession
    val spark = SparkSession.builder()
      .appName("Assignment 01")
      .getOrCreate()

    // Read CSV file with inferred schema
    val dfInferredSchema = spark.read.option("header", true).csv("Divvy_Trips_2015-Q1.csv")
    println("DataFrame with Inferred Schema:")
    dfInferredSchema.printSchema()
    println("Number of records: " + dfInferredSchema.count())

    // Define schema programmatically using StructFields
    val schema = StructType(
      StructField("some_field", StringType, nullable = true) :: // Example field, replace with actual fields
      StructField("another_field", IntegerType, nullable = true) :: Nil // Example field, replace with actual fields
    )
    val dfProgrammaticSchema = spark.read.option("header", true).schema(schema).csv("Divvy_Trips_2015-Q1.csv")
    println("DataFrame with Programmatically Defined Schema:")
    dfProgrammaticSchema.printSchema()
    println("Number of records: " + dfProgrammaticSchema.count())

    // Define schema using DDL
    val ddlSchema = "some_field STRING, another_field INT" // Example DDL schema, replace with actual schema
    val dfDDL = spark.read.option("header", true).option("inferSchema", false).schema(ddlSchema).csv("Divvy_Trips_2015-Q1.csv")
    println("DataFrame with Schema Defined via DDL:")
    dfDDL.printSchema()
    println("Number of records: " + dfDDL.count())

    // Perform Transformations and Actions
    // Select Gender based on last name
    val lastName = "Raorane"
    val gender = if (lastName.toLowerCase <= "k") "female" else "male"
    println("Selected Gender based on last name: " + gender)

    // GroupBy station to name and show 10 records
    val groupedDF = dfInferredSchema.groupBy("station").agg(count("*").alias("count")).limit(10)
    println("Grouped DataFrame:")
    groupedDF.show()

    // Stop SparkSession
    spark.stop()
  }
}
